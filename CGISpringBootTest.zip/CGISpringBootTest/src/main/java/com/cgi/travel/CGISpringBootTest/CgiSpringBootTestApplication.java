package com.cgi.travel.CGISpringBootTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableAutoConfiguration(exclude=DataSourceAutoConfiguration.class)
@ComponentScan(basePackages = { "com.cgi.*" })
@EntityScan(basePackages = "com.cgi.*")

public class CgiSpringBootTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgiSpringBootTestApplication.class, args);
	}
}
